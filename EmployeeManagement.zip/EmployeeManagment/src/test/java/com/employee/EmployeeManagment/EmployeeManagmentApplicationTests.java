package com.employee.EmployeeManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
